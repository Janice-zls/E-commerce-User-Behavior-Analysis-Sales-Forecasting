import pandas as pd
import traceback

try:
    print("开始加载数据...")
    df = pd.read_csv(r'g:\A.lsit\08.建模\校赛-B 题  销售商品行为预测\问题1\cleaned_data.csv', encoding='utf-8-sig')
    print(f"数据加载成功，共 {len(df)} 行")
    print(f"列名: {df.columns.tolist()}")
    print(f"\n行为分布:\n{df['行为'].value_counts()}")
    
    purchase_df = df[df['行为'] == '购买'].copy()
    print(f"\n购买数据: {len(purchase_df)} 行")
    print(f"购买数据列: {purchase_df.columns.tolist()}")
    print(f"权益值: {purchase_df['权益'].unique()}")
    print(f"性别值: {purchase_df['性别'].unique()}")
    print(f"商品类型: {purchase_df['商品类型'].unique()}")
    
except Exception as e:
    print(f"错误: {e}")
    traceback.print_exc()
