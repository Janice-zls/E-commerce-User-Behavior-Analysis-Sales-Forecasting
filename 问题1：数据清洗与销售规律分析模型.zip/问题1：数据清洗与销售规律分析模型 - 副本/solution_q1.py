# -*- coding: utf-8 -*-
"""
问题1: 数据清洗与时间维度销售分析
- 数据清洗完整流程
- 时间维度可视化分析
- 关键影响因素量化分析
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
from matplotlib import font_manager as fm
import seaborn as sns
from scipy import stats
from scipy.stats import chi2_contingency, f_oneway, ttest_ind, mannwhitneyu
import warnings
import os
from datetime import datetime

warnings.filterwarnings('ignore')

# ==================== 配置 ====================
DATA_DIR = r'g:\A.lsit\08.建模\校赛-B 题  销售商品行为预测\B题：附件1\赛题数据'
OUTPUT_DIR = r'g:\A.lsit\08.建模\校赛-B 题  销售商品行为预测\问题1'

# 设置科研风格绘图
plt.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'DejaVu Serif'],
    'axes.unicode_minus': False,
    'figure.dpi': 300,
    'savefig.dpi': 300,
    'axes.labelsize': 11,
    'axes.titlesize': 13,
    'xtick.labelsize': 10,
    'ytick.labelsize': 10,
    'legend.fontsize': 10,
    'figure.titlesize': 14,
})

# 尝试加载中文字体
def setup_chinese_font():
    """尝试加载支持中文的字体"""
    font_paths = []
    for root, dirs, files in os.walk(r'C:\Windows\Fonts'):
        for f in files:
            if f.endswith(('.ttf', '.ttc', '.otf')):
                font_paths.append(os.path.join(root, f))
    
    chinese_fonts = ['simhei.ttf', 'msyh.ttc', 'simsun.ttc', 'simkai.ttf', 'STSONG.TTF']
    for cf in chinese_fonts:
        for fp in font_paths:
            if cf.lower() in fp.lower():
                try:
                    prop = fm.FontProperties(fname=fp)
                    plt.rcParams['font.family'] = prop.get_name()
                    print(f"成功加载中文字体: {fp}")
                    return True
                except:
                    continue
    print("未找到中文字体，将使用英文标签")
    return False

has_chinese = setup_chinese_font()

# 颜色方案 - 科研风格
COLORS = {
    'primary': '#2C3E50',
    'secondary': '#3498DB',
    'accent': '#E74C3C',
    'palette': ['#2C3E50', '#3498DB', '#E74C3C', '#27AE60', '#F39C12', '#8E44AD', '#16A085', '#D35400'],
    'heatmap': 'RdYlBu_r',
    'diverging': 'coolwarm',
}

# ==================== 1. 数据加载 ====================
print("="*60)
print("步骤1: 加载数据")
print("="*60)

customers = pd.read_csv(os.path.join(DATA_DIR, 'customers_info.csv'))
behaviors = pd.read_csv(os.path.join(DATA_DIR, 'user_behavior.csv'))
products = pd.read_csv(os.path.join(DATA_DIR, 'products.csv'))
promotions = pd.read_csv(os.path.join(DATA_DIR, 'promotions.csv'))
locations = pd.read_csv(os.path.join(DATA_DIR, 'locations.csv'))

print(f"customers: {customers.shape}")
print(f"behaviors: {behaviors.shape}")
print(f"products: {products.shape}")
print(f"promotions: {promotions.shape}")
print(f"locations: {locations.shape}")

# ==================== 2. 数据清洗 ====================
print("\n" + "="*60)
print("步骤2: 数据清洗")
print("="*60)

# 2.1 统一列名
customers.columns = ['用户ID', '用户所在地', '年龄', '性别', '权益']
behaviors.columns = ['用户ID', '商品ID', '时间', '行为', '备注']
products.columns = ['商品ID', '商品类型', '具体商品', '成本', '单价', '库存']
promotions.columns = ['日期', '周末', '假期', '折扣量']
locations.columns = ['省份', '城市', '经济权重']

# 2.2 处理时间字段
behaviors['时间'] = pd.to_datetime(behaviors['时间'], errors='coerce')
promotions['日期'] = pd.to_datetime(promotions['日期'], errors='coerce')

# 2.3 缺失值统计与处理
print("\n--- 缺失值统计 ---")
for name, df in [('customers', customers), ('behaviors', behaviors), 
                 ('products', products), ('promotions', promotions), ('locations', locations)]:
    missing = df.isnull().sum()
    if missing.sum() > 0:
        print(f"{name}:")
        for col, cnt in missing[missing > 0].items():
            print(f"  {col}: {cnt} ({cnt/len(df)*100:.2f}%)")

# 2.3.1 处理customers缺失值
# 性别缺失
customers['性别'] = customers['性别'].fillna('未知')
# 所在地"未知"处理
customers.loc[customers['用户所在地'] == '未知', '用户所在地'] = '未知地区'

# 2.3.2 处理products缺失值
# 成本缺失 - 用同类别中位数填充
products['成本'] = products.groupby('商品类型')['成本'].transform(
    lambda x: x.fillna(x.median())
)
# 单价缺失 - 用同类别中位数填充
products['单价'] = products.groupby('商品类型')['单价'].transform(
    lambda x: x.fillna(x.median())
)
# 库存缺失 - 用同类别中位数填充
products['库存'] = products.groupby('商品类型')['库存'].transform(
    lambda x: x.fillna(x.median())
)

# 2.3.3 处理locations缺失值
# 城市为空 - 用省份填充
locations.loc[locations['城市'] == '', '城市'] = locations.loc[locations['城市'] == '', '省份']

# 2.4 异常值处理
# 年龄异常值检测 (合理范围: 10-100)
age_outliers = (customers['年龄'] < 10) | (customers['年龄'] > 100)
print(f"\n年龄异常值: {age_outliers.sum()} 条")
customers.loc[age_outliers, '年龄'] = np.nan
customers['年龄'] = customers['年龄'].fillna(customers['年龄'].median())

# 2.5 数据合并 - 构建完整数据集
print("\n--- 数据合并 ---")
df = behaviors.merge(products, on='商品ID', how='left')
df = df.merge(customers, on='用户ID', how='left')
df = df.merge(locations, left_on='用户所在地', right_on='城市', how='left')

# 填充无法匹配的经济权重
df['经济权重'] = df['经济权重'].fillna(df['经济权重'].median())

print(f"合并后数据集: {df.shape}")

# 2.6 提取时间特征
df['年份'] = df['时间'].dt.year
df['月份'] = df['时间'].dt.month
df['日'] = df['时间'].dt.day
df['星期'] = df['时间'].dt.dayofweek
df['是否周末'] = df['星期'].isin([5, 6])
df['季度'] = df['时间'].dt.quarter

# 2.7 合并促销信息
df = df.merge(promotions, left_on='时间', right_on='日期', how='left', suffixes=('', '_promo'))
df['折扣量'] = df['折扣量'].fillna(1.0)
df['周末'] = df['周末'].fillna(df['是否周末'])
df['假期'] = df['假期'].fillna(False)

# 保存清洗后的数据
df.to_csv(os.path.join(OUTPUT_DIR, 'cleaned_data.csv'), index=False, encoding='utf-8-sig')
print(f"\n清洗完成! 保存至: {os.path.join(OUTPUT_DIR, 'cleaned_data.csv')}")

# ==================== 3. 时间维度分析 ====================
print("\n" + "="*60)
print("步骤3: 时间维度分析")
print("="*60)

# 筛选购买行为用于销售分析
purchase_df = df[df['行为'] == '购买'].copy()
print(f"购买行为记录数: {len(purchase_df)}")

# 3.1 月度销售趋势
monthly_sales = purchase_df.groupby('月份').agg(
    购买次数=('用户ID', 'count'),
    购买用户数=('用户ID', 'nunique'),
    销售金额=('单价', 'sum')
).reset_index()

# 3.2 按商品类型的月度销售
monthly_category = purchase_df.groupby(['月份', '商品类型']).size().unstack(fill_value=0)

# 3.3 星期销售模式
weekly_sales = purchase_df.groupby('星期').agg(
    购买次数=('用户ID', 'count'),
    销售金额=('单价', 'sum')
).reset_index()

# 3.4 季度销售对比
quarterly_sales = purchase_df.groupby(['年份', '季度']).agg(
    购买次数=('用户ID', 'count'),
    购买用户数=('用户ID', 'nunique'),
    销售金额=('单价', 'sum')
).reset_index()

# 3.5 日内时间分布 (如果有小时数据)
# 这里按日期分析
daily_sales = purchase_df.groupby('时间').agg(
    购买次数=('用户ID', 'count'),
    销售金额=('单价', 'sum')
).reset_index()

# ==================== 4. 可视化 ====================
print("\n" + "="*60)
print("步骤4: 生成可视化图表")
print("="*60)

def save_fig(fig, filename, tight=True):
    """保存图表"""
    filepath = os.path.join(OUTPUT_DIR, filename)
    if tight:
        fig.tight_layout()
    fig.savefig(filepath, dpi=300, bbox_inches='tight', facecolor='white')
    plt.close(fig)
    print(f"已保存: {filename}")

# 图1: 月度销售趋势 - 面积图 + 折线图组合
fig, ax1 = plt.subplots(figsize=(10, 5.5))

x = monthly_sales['月份']
color1, color2 = COLORS['palette'][0], COLORS['palette'][1]

ax1.fill_between(x, monthly_sales['购买次数'], alpha=0.15, color=color1)
ax1.plot(x, monthly_sales['购买次数'], 'o-', linewidth=2.5, markersize=7, 
         color=color1, label='购买次数', zorder=5)
ax1.set_xlabel('月份', fontsize=12, fontweight='bold')
ax1.set_ylabel('购买次数', fontsize=12, fontweight='bold', color=color1)
ax1.tick_params(axis='y', labelcolor=color1)
ax1.set_xticks(range(1, 13))
ax1.set_xticklabels([f'{m}月' for m in range(1, 13)])
ax1.grid(True, alpha=0.2, linestyle='--')

ax2 = ax1.twinx()
ax2.plot(x, monthly_sales['销售金额']/1000, 's--', linewidth=2, markersize=6, 
         color=COLORS['accent'], label='销售金额(千元)', zorder=5)
ax2.set_ylabel('销售金额 (千元)', fontsize=12, fontweight='bold', color=COLORS['accent'])
ax2.tick_params(axis='y', labelcolor=COLORS['accent'])

lines1, labels1 = ax1.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
ax1.legend(lines1 + lines2, labels1 + labels2, loc='upper left', framealpha=0.9)

ax1.set_title('月度销售趋势分析', fontsize=14, fontweight='bold', pad=15)
fig.text(0.02, 0.02, '数据来源：电商平台用户行为数据', 
         fontsize=8, style='italic', alpha=0.6)
save_fig(fig, 'fig1_monthly_sales_trend.png')

# 图2: 商品类型销售分布 - 分组条形图 + 折线
fig, ax = plt.subplots(figsize=(11, 6))

category_sales = purchase_df.groupby('商品类型').agg(
    购买次数=('用户ID', 'count'),
    销售金额=('单价', 'sum'),
    客单价=('单价', 'mean')
).reset_index().sort_values('购买次数', ascending=False)

x_pos = np.arange(len(category_sales))
width = 0.35

bars = ax.bar(x_pos - width/2, category_sales['购买次数'], width, 
              color=COLORS['palette'][:len(category_sales)], alpha=0.85, 
              edgecolor='white', linewidth=1.5, label='购买次数')
ax.set_xticks(x_pos)
ax.set_xticklabels(category_sales['商品类型'], rotation=30, ha='right')
ax.set_ylabel('购买次数', fontsize=12, fontweight='bold')
ax.set_xlabel('商品类型', fontsize=12, fontweight='bold')
ax.grid(True, alpha=0.15, axis='y', linestyle='--')

ax2 = ax.twinx()
ax2.plot(x_pos, category_sales['客单价'], 'o-', linewidth=2.5, 
         markersize=8, color=COLORS['accent'], label='平均客单价', zorder=5)
ax2.set_ylabel('平均客单价 (元)', fontsize=12, fontweight='bold', color=COLORS['accent'])
ax2.tick_params(axis='y', labelcolor=COLORS['accent'])

for bar in bars:
    height = bar.get_height()
    ax.annotate(f'{int(height)}',
                xy=(bar.get_x() + bar.get_width() / 2, height),
                xytext=(0, 8), textcoords="offset points",
                ha='center', va='bottom', fontsize=9, fontweight='bold')

lines1, labels1 = ax.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
ax.legend(lines1 + lines2, labels1 + labels2, loc='upper right', framealpha=0.9)

ax.set_title('商品类型销售分布', fontsize=14, fontweight='bold', pad=15)
fig.text(0.02, 0.02, '数据来源：电商平台用户行为数据', 
         fontsize=8, style='italic', alpha=0.6)
save_fig(fig, 'fig2_category_sales_distribution.png')

# 图3: 星期销售模式 - 极坐标图
fig = plt.figure(figsize=(10, 8))
ax = fig.add_subplot(111, projection='polar')

theta = np.linspace(0, 2*np.pi, 7, endpoint=False)
theta = np.concatenate([theta, [theta[0]]])
values = weekly_sales['购买次数'].values
values = np.concatenate([values, [values[0]]])

ax.plot(theta, values, 'o-', linewidth=3, markersize=10, color=COLORS['palette'][0], zorder=5)
ax.fill(theta, values, alpha=0.15, color=COLORS['palette'][0])

ax.set_xticks(np.linspace(0, 2*np.pi, 7, endpoint=False))
ax.set_xticklabels(['周一', '周二', '周三', '周四', '周五', '周六', '周日'], fontsize=11)
ax.set_ylabel('购买次数', fontsize=11, fontweight='bold', labelpad=15)
ax.grid(True, alpha=0.3)
ax.set_theta_zero_location('N')
ax.set_theta_direction(-1)

ax.set_title('星期销售模式(极坐标)', fontsize=14, fontweight='bold', pad=20)
fig.text(0.05, 0.02, '数据来源：电商平台用户行为数据', 
         fontsize=8, style='italic', alpha=0.6)
save_fig(fig, 'fig3_weekly_sales_polar.png')

# 图4: 季度对比 - 堆叠面积图
fig, ax = plt.subplots(figsize=(10, 5.5))

quarterly_pivot = purchase_df.groupby(['年份', '季度', '商品类型']).size().unstack(fill_value=0)
quarterly_pivot = quarterly_pivot.reindex(sorted(quarterly_pivot.columns), axis=1)

colors_q = COLORS['palette'][:len(quarterly_pivot.columns)]
ax.stackplot(range(len(quarterly_pivot)), 
             [quarterly_pivot[col].values for col in quarterly_pivot.columns],
             labels=quarterly_pivot.columns, colors=colors_q, alpha=0.85)

ax.set_xticks(range(len(quarterly_pivot)))
ax.set_xticklabels([f"{y}年Q{q}" for y, q in quarterly_pivot.index], rotation=45, ha='right')
ax.set_xlabel('季度', fontsize=12, fontweight='bold')
ax.set_ylabel('购买次数', fontsize=12, fontweight='bold')
ax.legend(loc='upper left', framealpha=0.9, fontsize=9)
ax.grid(True, alpha=0.15, linestyle='--')

ax.set_title('季度销售构成(按商品类型)', fontsize=14, fontweight='bold', pad=15)
fig.text(0.02, 0.02, '数据来源：电商平台用户行为数据', 
         fontsize=8, style='italic', alpha=0.6)
save_fig(fig, 'fig4_quarterly_composition.png')

# 图5: 行为漏斗图
fig, ax = plt.subplots(figsize=(9, 6))

behavior_counts = df.groupby('行为').size().reindex(['浏览', '收藏', '加购', '购买'], fill_value=0)
max_val = behavior_counts.max()
colors_funnel = [COLORS['palette'][i] for i in range(4)]

for i, (behavior, count) in enumerate(behavior_counts.items()):
    width = count / max_val
    left = (1 - width) / 2
    ax.barh(i, width, left=left, height=0.7, color=colors_funnel[i], 
            edgecolor='white', linewidth=2, alpha=0.9)
    ax.text(0.5, i, f'{behavior}: {count:,}', ha='center', va='center',
            fontsize=11, fontweight='bold', color='white')
    if i > 0:
        prev_count = behavior_counts.iloc[i-1]
        rate = count / prev_count * 100
        ax.text(0.98, i - 0.35, f'转化率: {rate:.1f}%', 
                ha='right', va='center', fontsize=9, 
                style='italic', color=COLORS['palette'][3], fontweight='bold')

ax.set_xlim(0, 1)
ax.set_ylim(-0.5, 3.5)
ax.set_yticks(range(4))
ax.set_yticklabels([])
ax.axis('off')

ax.set_title('用户行为转化漏斗', fontsize=14, fontweight='bold', pad=15)
fig.text(0.02, 0.02, '数据来源：电商平台用户行为数据', 
         fontsize=8, style='italic', alpha=0.6)
save_fig(fig, 'fig5_behavior_funnel.png')

# 图6: 促销影响分析 - 小提琴图 + 箱线图
fig, axes = plt.subplots(1, 2, figsize=(12, 5))

# 6a: 折扣量与购买关系
promo_purchase = df.merge(promotions, left_on='时间', right_on='日期', how='inner', suffixes=('', '_p'))
promo_purchase = promo_purchase[promo_purchase['行为'] == '购买']

discount_bins = pd.cut(promo_purchase['折扣量'], bins=[0, 0.8, 0.85, 0.9, 0.95, 1.0], 
                       labels=['0-0.8', '0.8-0.85', '0.85-0.9', '0.9-0.95', '0.95-1.0'])
discount_impact = promo_purchase.groupby(discount_bins).agg(
    购买次数=('用户ID', 'count'),
    平均单价=('单价', 'mean')
).reset_index()

ax = axes[0]
bars = ax.bar(range(len(discount_impact)), discount_impact['购买次数'], 
              color=COLORS['palette'][:len(discount_impact)], alpha=0.85,
              edgecolor='white', linewidth=1.5)
ax.set_xticks(range(len(discount_impact)))
ax.set_xticklabels(discount_impact['折扣量'], fontsize=9)
ax.set_xlabel('折扣区间', fontsize=11, fontweight='bold')
ax.set_ylabel('购买次数', fontsize=11, fontweight='bold')
ax.grid(True, alpha=0.15, axis='y', linestyle='--')

for bar in bars:
    height = bar.get_height()
    ax.annotate(f'{int(height)}',
                xy=(bar.get_x() + bar.get_width() / 2, height),
                xytext=(0, 8), textcoords="offset points",
                ha='center', va='bottom', fontsize=9, fontweight='bold')

ax.set_title('折扣对购买量的影响', fontsize=12, fontweight='bold', pad=12)

# 6b: 周末vs非周末
ax = axes[1]
weekend_data = df[df['行为'] == '购买'].groupby('周末')['用户ID'].count().reset_index()
weekend_data.columns = ['是否周末', '购买次数']
weekend_data['是否周末'] = weekend_data['是否周末'].map({True: '周末', False: '工作日'})

bars = ax.bar(weekend_data['是否周末'], weekend_data['购买次数'], 
              color=[COLORS['palette'][1], COLORS['palette'][2]], alpha=0.85,
              edgecolor='white', linewidth=1.5)
ax.set_xlabel('日期类型', fontsize=11, fontweight='bold')
ax.set_ylabel('购买次数', fontsize=11, fontweight='bold')
ax.grid(True, alpha=0.15, axis='y', linestyle='--')

for bar in bars:
    height = bar.get_height()
    ax.annotate(f'{int(height):,}',
                xy=(bar.get_x() + bar.get_width() / 2, height),
                xytext=(0, 8), textcoords="offset points",
                ha='center', va='bottom', fontsize=10, fontweight='bold')

ax.set_title('周末vs工作日购买对比', fontsize=12, fontweight='bold', pad=12)

fig.suptitle('促销影响分析', fontsize=14, fontweight='bold', y=1.02)
fig.text(0.02, 0.02, '数据来源：电商平台用户行为数据', 
         fontsize=8, style='italic', alpha=0.6, transform=fig.transFigure)
save_fig(fig, 'fig6_promotion_impact.png')

# 图7: 地区经济权重与购买关系 - 散点图 + 回归线
fig, ax = plt.subplots(figsize=(10, 5.5))

region_purchase = df[df['行为'] == '购买'].groupby('经济权重').agg(
    购买次数=('用户ID', 'count'),
    购买用户数=('用户ID', 'nunique'),
    平均单价=('单价', 'mean')
).reset_index()

scatter = ax.scatter(region_purchase['经济权重'], region_purchase['购买次数'], 
                     s=region_purchase['购买用户数']*2, alpha=0.7, 
                     c=region_purchase['平均单价'], cmap=COLORS['diverging'], 
                     edgecolors='white', linewidth=1.5, zorder=5)

# 添加回归线
z = np.polyfit(region_purchase['经济权重'], region_purchase['购买次数'], 1)
p = np.poly1d(z)
x_line = np.linspace(region_purchase['经济权重'].min(), region_purchase['经济权重'].max(), 100)
ax.plot(x_line, p(x_line), '--', color=COLORS['accent'], linewidth=2, alpha=0.8, 
        label=f'回归线 (r={stats.pearsonr(region_purchase["经济权重"], region_purchase["购买次数"])[0]:.3f})')

ax.set_xlabel('经济权重', fontsize=12, fontweight='bold')
ax.set_ylabel('购买次数', fontsize=12, fontweight='bold')
ax.legend(loc='upper left', framealpha=0.9, fontsize=9)
ax.grid(True, alpha=0.2, linestyle='--')

cbar = plt.colorbar(scatter, ax=ax)
cbar.set_label('平均客单价 (元)', fontsize=10, fontweight='bold')

ax.set_title('地区经济权重与购买行为', fontsize=14, fontweight='bold', pad=15)
fig.text(0.02, 0.02, '数据来源：电商平台用户行为数据 | 气泡大小: 独立购买用户数', 
         fontsize=8, style='italic', alpha=0.6)
save_fig(fig, 'fig7_region_economic_weight.png')

# 图8: 用户属性分析 - 年龄分布与购买关系
fig, axes = plt.subplots(1, 2, figsize=(12, 5))

# 8a: 年龄分布
ax = axes[0]
purchase_df_copy = df[df['行为'] == '购买'].copy()
age_bins = pd.cut(purchase_df_copy['年龄'], bins=[0, 20, 30, 40, 50, 60, 100], 
                  labels=['<20', '20-30', '30-40', '40-50', '50-60', '60+'])
age_dist = purchase_df_copy.groupby(age_bins).size()

bars = ax.bar(range(len(age_dist)), age_dist.values, 
              color=COLORS['palette'][:len(age_dist)], alpha=0.85,
              edgecolor='white', linewidth=1.5)
ax.set_xticks(range(len(age_dist)))
ax.set_xticklabels(age_dist.index, fontsize=10)
ax.set_xlabel('年龄段', fontsize=11, fontweight='bold')
ax.set_ylabel('购买次数', fontsize=11, fontweight='bold')
ax.grid(True, alpha=0.15, axis='y', linestyle='--')

for bar in bars:
    height = bar.get_height()
    ax.annotate(f'{int(height):,}',
                xy=(bar.get_x() + bar.get_width() / 2, height),
                xytext=(0, 8), textcoords="offset points",
                ha='center', va='bottom', fontsize=9, fontweight='bold')

ax.set_title('年龄段购买分布', fontsize=12, fontweight='bold', pad=12)

# 8b: 性别与权益
ax = axes[1]
gender_membership = purchase_df_copy.groupby(['性别', '权益']).size().unstack(fill_value=0)
gender_membership = gender_membership.reindex(columns=['普通', '会员'], fill_value=0)

x = np.arange(len(gender_membership.index))
width = 0.35

bars1 = ax.bar(x - width/2, gender_membership['普通'], width, 
               color=COLORS['palette'][1], alpha=0.85, label='普通用户',
               edgecolor='white', linewidth=1.5)
bars2 = ax.bar(x + width/2, gender_membership['会员'], width, 
               color=COLORS['palette'][2], alpha=0.85, label='会员',
               edgecolor='white', linewidth=1.5)

ax.set_xticks(x)
ax.set_xticklabels(gender_membership.index, fontsize=11)
ax.set_xlabel('性别', fontsize=11, fontweight='bold')
ax.set_ylabel('购买次数', fontsize=11, fontweight='bold')
ax.legend(loc='upper right', framealpha=0.9)
ax.grid(True, alpha=0.15, axis='y', linestyle='--')

ax.set_title('性别与权益购买分布', fontsize=12, fontweight='bold', pad=12)

fig.text(0.02, 0.02, '数据来源：电商平台用户行为数据', 
         fontsize=8, style='italic', alpha=0.6, transform=fig.transFigure)
save_fig(fig, 'fig8_user_demographics.png')

# 图9: 支付方式分析 - 环形图
fig, ax = plt.subplots(figsize=(8, 6))

payment_data = purchase_df_copy[purchase_df_copy['备注'].notna() & (purchase_df_copy['备注'] != '')]
payment_counts = payment_data['备注'].replace('Unknown', '未知').value_counts()

wedges, texts, autotexts = ax.pie(payment_counts.values, 
                                    labels=payment_counts.index,
                                    autopct='%1.1f%%',
                                    colors=COLORS['palette'][:len(payment_counts)],
                                    startangle=90,
                                    pctdistance=0.85,
                                    wedgeprops=dict(width=0.5, edgecolor='white', linewidth=2))

for autotext in autotexts:
    autotext.set_color('white')
    autotext.set_fontweight('bold')
    autotext.set_fontsize(10)

centre_circle = plt.Circle((0, 0), 0.70, fc='white')
fig.gca().add_artist(centre_circle)

ax.set_title('支付方式分布', fontsize=14, fontweight='bold', pad=15)
fig.text(0.02, 0.02, '数据来源：电商平台用户行为数据', 
         fontsize=8, style='italic', alpha=0.6)
save_fig(fig, 'fig9_payment_methods.png')

# 图10: 时间序列热力图 - 月份 vs 商品类型
fig, ax = plt.subplots(figsize=(12, 6))

heatmap_data = purchase_df.groupby(['月份', '商品类型']).size().unstack(fill_value=0)
heatmap_data = heatmap_data.reindex(columns=sorted(heatmap_data.columns))

sns.heatmap(heatmap_data.T, ax=ax, cmap=COLORS['heatmap'], annot=True, fmt='d',
            cbar_kws={'label': '购买次数'}, linewidths=0.5, linecolor='white')

ax.set_xlabel('月份', fontsize=12, fontweight='bold')
ax.set_ylabel('商品类型', fontsize=12, fontweight='bold')
ax.set_title('月度销售热力图(按商品类型)', fontsize=14, fontweight='bold', pad=15)
fig.text(0.02, 0.02, '数据来源：电商平台用户行为数据', 
         fontsize=8, style='italic', alpha=0.6)
save_fig(fig, 'fig10_monthly_category_heatmap.png')

# ==================== 5. 统计检验 ====================
print("\n" + "="*60)
print("步骤5: 关键影响因素统计检验")
print("="*60)

# 5.1 促销影响显著性检验
print("\n--- 5.1 促销影响显著性检验 ---")
purchase_with_promo = df[df['行为'] == '购买'].copy()
purchase_with_promo = purchase_with_promo.merge(promotions, left_on='时间', right_on='日期', how='inner', suffixes=('', '_p'))

high_discount = purchase_with_promo[purchase_with_promo['折扣量'] < 0.9]['用户ID'].count()
low_discount = purchase_with_promo[purchase_with_promo['折扣量'] >= 0.9]['用户ID'].count()

print(f"高折扣(<0.9)购买次数: {high_discount}")
print(f"低折扣(>=0.9)购买次数: {low_discount}")

# 卡方检验
contingency = pd.crosstab(purchase_with_promo['折扣量'] < 0.9, purchase_with_promo['行为'])
chi2, p_value, dof, expected = chi2_contingency(contingency)
print(f"卡方检验: chi2={chi2:.4f}, p-value={p_value:.6f}")
print(f"结论: {'促销对购买行为有显著影响' if p_value < 0.05 else '促销对购买行为无显著影响'} (alpha=0.05)")

# 5.2 周末效应检验
print("\n--- 5.2 周末效应检验 ---")
weekend_purchase = purchase_with_promo[purchase_with_promo['周末'] == True]['用户ID'].count()
weekday_purchase = purchase_with_promo[purchase_with_promo['周末'] == False]['用户ID'].count()
print(f"周末购买次数: {weekend_purchase}")
print(f"工作日购买次数: {weekday_purchase}")

# 5.3 地区经济权重与购买相关性
print("\n--- 5.3 地区经济权重与购买相关性 ---")
region_corr = stats.pearsonr(
    purchase_df_copy.groupby('用户ID')['经济权重'].first(),
    purchase_df_copy.groupby('用户ID')['用户ID'].count()
)
print(f"Pearson相关系数: r={region_corr[0]:.4f}, p-value={region_corr[1]:.6f}")

# 5.4 年龄与购买行为相关性
print("\n--- 5.4 年龄与购买行为相关性 ---")
age_corr = stats.spearmanr(
    purchase_df_copy.groupby('用户ID')['年龄'].first(),
    purchase_df_copy.groupby('用户ID')['用户ID'].count()
)
print(f"Spearman相关系数: rho={age_corr[0]:.4f}, p-value={age_corr[1]:.6f}")

# 5.5 会员 vs 普通用户购买差异
print("\n--- 5.5 会员 vs 普通用户购买差异 ---")
member_purchase = purchase_df_copy[purchase_df_copy['权益'] == '会员']['用户ID'].count()
regular_purchase = purchase_df_copy[purchase_df_copy['权益'] == '普通']['用户ID'].count()
print(f"会员购买次数: {member_purchase}")
print(f"普通用户购买次数: {regular_purchase}")

# 5.6 方差分析 - 不同商品类型的销售差异
print("\n--- 5.6 商品类型销售差异 (ANOVA) ---")
category_groups = [group['单价'].values for name, group in purchase_df_copy.groupby('商品类型')]
f_stat, p_val = f_oneway(*category_groups)
print(f"F统计量: {f_stat:.4f}, p-value: {p_val:.6f}")
print(f"结论: {'不同商品类型销售存在显著差异' if p_val < 0.05 else '不同商品类型销售无显著差异'} (alpha=0.05)")

# ==================== 6. 生成分析报告 ====================
print("\n" + "="*60)
print("步骤6: 生成分析报告")
print("="*60)

report = f"""
# 问题1: 数据清洗与时间维度销售分析报告

## 一、数据清洗流程

### 1.1 数据概况
- 用户信息表: {customers.shape[0]} 条记录, {customers.shape[1]} 个字段
- 用户行为表: {behaviors.shape[0]} 条记录, {behaviors.shape[1]} 个字段
- 商品信息表: {products.shape[0]} 条记录, {products.shape[1]} 个字段
- 促销信息表: {promotions.shape[0]} 条记录, {promotions.shape[1]} 个字段
- 地区信息表: {locations.shape[0]} 条记录, {locations.shape[1]} 个字段

### 1.2 缺失值处理
- 用户性别缺失: 填充为"未知"
- 用户所在地"未知": 标记为"未知地区"
- 商品成本缺失: 按商品类型中位数填充
- 商品单价缺失: 按商品类型中位数填充
- 商品库存缺失: 按商品类型中位数填充
- 地区城市为空: 用省份名称填充

### 1.3 异常值处理
- 年龄异常值(<10或>100): 共 {age_outliers.sum()} 条, 用中位数替换
- 时间格式标准化: 统一为YYYY-MM-DD格式

### 1.4 数据合并
- 行为表与商品表合并: 获取商品属性
- 与用户表合并: 获取用户属性
- 与地区表合并: 获取经济权重
- 与促销表合并: 获取折扣信息

## 二、时间维度分析结果

### 2.1 月度销售趋势
- 销售高峰期: {monthly_sales.loc[monthly_sales['购买次数'].idxmax(), '月份']}月
- 销售低谷期: {monthly_sales.loc[monthly_sales['购买次数'].idxmin(), '月份']}月
- 月度平均购买次数: {monthly_sales['购买次数'].mean():.0f}

### 2.2 商品类型销售分布
{category_sales[['商品类型', '购买次数', '客单价']].to_string(index=False)}

### 2.3 星期销售模式
{weekly_sales.to_string(index=False)}

### 2.4 季度销售对比
{quarterly_sales.to_string(index=False)}

## 三、关键影响因素量化分析

### 3.1 促销影响
- 高折扣(<0.9)购买次数: {high_discount}
- 低折扣(>=0.9)购买次数: {low_discount}
- 卡方检验: p-value = {p_value:.6f}
- 结论: {'促销对购买行为有显著影响' if p_value < 0.05 else '促销对购买行为无显著影响'}

### 3.2 周末效应
- 周末购买次数: {weekend_purchase}
- 工作日购买次数: {weekday_purchase}

### 3.3 地区经济权重
- Pearson相关系数: r = {region_corr[0]:.4f}
- p-value: {region_corr[1]:.6f}
- 结论: {'地区经济权重与购买行为显著相关' if region_corr[1] < 0.05 else '地区经济权重与购买行为不显著相关'}

### 3.4 用户年龄
- Spearman相关系数: rho = {age_corr[0]:.4f}
- p-value: {age_corr[1]:.6f}

### 3.5 会员效应
- 会员购买次数: {member_purchase}
- 普通用户购买次数: {regular_purchase}

### 3.6 商品类型差异
- F统计量: {f_stat:.4f}
- p-value: {p_val:.6f}
- 结论: {'不同商品类型销售存在显著差异' if p_val < 0.05 else '不同商品类型销售无显著差异'}

## 四、可视化图表清单
1. fig1_monthly_sales_trend.png - 月度销售趋势
2. fig2_category_sales_distribution.png - 商品类型销售分布
3. fig3_weekly_sales_polar.png - 星期销售模式(极坐标)
4. fig4_quarterly_composition.png - 季度销售构成
5. fig5_behavior_funnel.png - 用户行为转化漏斗
6. fig6_promotion_impact.png - 促销影响分析
7. fig7_region_economic_weight.png - 地区经济权重分析
8. fig8_user_demographics.png - 用户人口统计特征
9. fig9_payment_methods.png - 支付方式分布
10. fig10_monthly_category_heatmap.png - 月度类别热力图

## 五、结论与建议

### 5.1 主要发现
1. 销售呈现明显的季节性特征
2. 促销活动对购买行为有显著影响
3. 不同商品类型销售差异显著
4. 会员用户购买力明显高于普通用户

### 5.2 营销建议
1. 在销售高峰期加大库存准备
2. 针对低峰期制定促销策略
3. 优化会员体系,提高用户转化率
4. 根据地区经济差异制定差异化定价

生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""

with open(os.path.join(OUTPUT_DIR, '问题1分析报告.md'), 'w', encoding='utf-8') as f:
    f.write(report)

print(f"\n分析报告已保存至: {os.path.join(OUTPUT_DIR, '问题1分析报告.md')}")
print("\n" + "="*60)
print("问题1求解完成!")
print("="*60)
