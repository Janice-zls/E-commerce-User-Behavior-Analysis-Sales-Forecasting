# -*- coding: utf-8 -*-
"""
问题1: 生成图14和图15
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
import seaborn as sns
from scipy import stats
import warnings
import os
from matplotlib.gridspec import GridSpec
import traceback

warnings.filterwarnings('ignore')

# ==================== 配置 ====================
DATA_DIR = r'g:\A.lsit\08.建模\校赛-B 题  销售商品行为预测\B题：附件1\赛题数据'
OUTPUT_DIR = r'g:\A.lsit\08.建模\校赛-B 题  销售商品行为预测\问题1'

plt.rcParams.update({
    'font.sans-serif': ['SimHei', 'Microsoft YaHei'],
    'axes.unicode_minus': False,
    'figure.dpi': 300,
    'savefig.dpi': 300,
    'axes.labelsize': 12,
    'axes.titlesize': 14,
    'xtick.labelsize': 11,
    'ytick.labelsize': 11,
    'legend.fontsize': 11,
    'figure.titlesize': 16,
})

COLORS = {
    'primary': '#1B4F72',
    'secondary': '#2E86C1',
    'accent': '#C0392B',
    'success': '#27AE60',
    'warning': '#F39C12',
    'palette': ['#1B4F72', '#2E86C1', '#C0392B', '#27AE60', '#F39C12', '#8E44AD', '#16A085', '#D35400', 
                '#2C3E50', '#E74C3C', '#3498DB', '#2980B9'],
}

def save_fig(fig, filename):
    try:
        filepath = os.path.join(OUTPUT_DIR, filename)
        fig.tight_layout()
        fig.savefig(filepath, dpi=300, bbox_inches='tight', facecolor='white')
        plt.close(fig)
        print(f"[OK] 已保存: {filename}")
        return True
    except Exception as e:
        print(f"[ERROR] 保存失败 {filename}: {e}")
        return False

# ==================== 数据加载 ====================
print("="*60)
print("加载数据")
print("="*60)

df = pd.read_csv(os.path.join(OUTPUT_DIR, 'cleaned_data.csv'), encoding='utf-8-sig')
df['时间'] = pd.to_datetime(df['时间'])
df['日期'] = pd.to_datetime(df['日期'])

purchase_df = df[df['行为'] == '购买'].copy()
print(f"总数据: {len(df)} 条, 购买数据: {len(purchase_df)} 条")

# 加载促销数据
promotions_df = pd.read_csv(os.path.join(DATA_DIR, 'promotions.csv'), encoding='utf-8-sig')
promotions_df.columns = ['日期', '周末', '假期', '折扣量']
promotions_df['日期'] = pd.to_datetime(promotions_df['日期'])

promo_purchase = purchase_df.merge(promotions_df, left_on='时间', right_on='日期', how='inner', suffixes=('', '_p'))
print(f"促销关联数据: {len(promo_purchase)} 条")

# ==================== 图14: 促销与地区影响分析 ====================
print("\n生成图14: 促销与地区影响分析")

try:
    fig = plt.figure(figsize=(14, 10))
    gs = GridSpec(2, 2, figure=fig, hspace=0.35, wspace=0.3)

    # 4a: 折扣量与购买关系
    ax1 = fig.add_subplot(gs[0, 0])
    
    discount_bins = pd.cut(promo_purchase['折扣量'], bins=[0, 0.8, 0.85, 0.9, 0.95, 1.0],
                           labels=['0-0.8', '0.8-0.85', '0.85-0.9', '0.9-0.95', '0.95-1.0'])
    discount_data = [group['单价'].values for name, group in promo_purchase.groupby(discount_bins)]

    parts = ax1.violinplot(discount_data, positions=range(5), widths=0.6,
                           showmeans=True, showmedians=True)

    for pc in parts['bodies']:
        pc.set_facecolor(COLORS['secondary'])
        pc.set_alpha(0.6)
        pc.set_edgecolor('white')

    ax1.set_xticks(range(5))
    ax1.set_xticklabels(['0-0.8', '0.8-0.85', '0.85-0.9', '0.9-0.95', '0.95-1.0'], fontsize=10)
    ax1.set_xlabel('折扣区间', fontsize=12, fontweight='bold')
    ax1.set_ylabel('客单价 (元)', fontsize=12, fontweight='bold')
    ax1.grid(True, alpha=0.15, axis='y', linestyle='--')
    ax1.set_title('折扣区间对客单价的影响', fontsize=13, fontweight='bold', pad=10)

    # 4b: 周末vs工作日对比
    ax2 = fig.add_subplot(gs[0, 1])
    weekend_data = promo_purchase.groupby('周末').agg(
        购买次数=('用户ID', 'count'),
        平均客单价=('单价', 'mean')
    ).reset_index()

    x = np.arange(2)
    width = 0.35

    bars1 = ax2.bar(x - width/2, weekend_data['购买次数'], width,
                    color=COLORS['primary'], alpha=0.85, label='购买次数',
                    edgecolor='white', linewidth=2)
    ax2.set_ylabel('购买次数', fontsize=12, fontweight='bold', color=COLORS['primary'])
    ax2.tick_params(axis='y', labelcolor=COLORS['primary'])

    ax2_twin = ax2.twinx()
    bars2 = ax2_twin.bar(x + width/2, weekend_data['平均客单价'], width,
                         color=COLORS['accent'], alpha=0.85, label='平均客单价',
                         edgecolor='white', linewidth=2)
    ax2_twin.set_ylabel('平均客单价 (元)', fontsize=12, fontweight='bold', color=COLORS['accent'])
    ax2_twin.tick_params(axis='y', labelcolor=COLORS['accent'])

    ax2.set_xticks(x)
    ax2.set_xticklabels(['工作日', '周末'], fontsize=11)
    ax2.grid(True, alpha=0.15, axis='y', linestyle='--')

    lines1, labels1 = ax2.get_legend_handles_labels()
    lines2, labels2 = ax2_twin.get_legend_handles_labels()
    ax2.legend(lines1 + lines2, labels1 + labels2, loc='upper right', framealpha=0.9)
    ax2.set_title('周末vs工作日销售对比', fontsize=13, fontweight='bold', pad=10)

    # 4c: 地区经济权重分布
    ax3 = fig.add_subplot(gs[1, 0])
    region_purchase = purchase_df.groupby('经济权重').agg(
        购买次数=('用户ID', 'count'),
        购买用户数=('用户ID', 'nunique'),
        平均客单价=('单价', 'mean')
    ).reset_index()

    scatter = ax3.scatter(region_purchase['经济权重'], region_purchase['购买次数'],
                          s=region_purchase['购买用户数']*3, alpha=0.7,
                          c=region_purchase['平均客单价'], cmap='RdBu_r',
                          edgecolors='white', linewidth=2, zorder=5)

    for i, txt in enumerate(region_purchase['经济权重']):
        ax3.annotate(f'{txt:.0f}', 
                     (region_purchase['经济权重'].iloc[i], region_purchase['购买次数'].iloc[i]),
                     xytext=(5, 5), textcoords='offset points', fontsize=9, fontweight='bold')

    ax3.set_xlabel('经济权重', fontsize=12, fontweight='bold')
    ax3.set_ylabel('购买次数', fontsize=12, fontweight='bold')
    ax3.grid(True, alpha=0.2, linestyle='--')
    cbar = plt.colorbar(scatter, ax=ax3)
    cbar.set_label('平均客单价 (元)', fontsize=10, fontweight='bold')
    ax3.set_title('地区经济权重与购买行为', fontsize=13, fontweight='bold', pad=10)

    # 4d: 假期效应分析
    ax4 = fig.add_subplot(gs[1, 1])
    calendar_data = promo_purchase.groupby(promo_purchase['时间'].dt.date).size()
    calendar_df = pd.DataFrame({'日期': calendar_data.index, '购买次数': calendar_data.values})
    calendar_df['月份'] = calendar_df['日期'].apply(lambda x: x.month)
    calendar_df['日'] = calendar_df['日期'].apply(lambda x: x.day)

    # 聚合重复的月-日组合（多年数据）
    pivot_calendar = calendar_df.groupby(['月份', '日'])['购买次数'].sum().unstack(fill_value=0)
    sns.heatmap(pivot_calendar, ax=ax4, cmap='YlOrRd', 
                cbar_kws={'label': '购买次数'}, linewidths=0.3, linecolor='white',
                annot=False)
    ax4.set_xlabel('日期', fontsize=12, fontweight='bold')
    ax4.set_ylabel('月份', fontsize=12, fontweight='bold')
    ax4.set_title('日历热力图：每日购买分布', fontsize=13, fontweight='bold', pad=10)

    fig.suptitle('促销与地区影响深度分析', fontsize=16, fontweight='bold', y=0.98)
    fig.text(0.02, 0.01, '数据来源：电商平台用户行为数据', fontsize=9, style='italic', alpha=0.6)
    save_fig(fig, 'fig14_promotion_region_analysis.png')
except Exception as e:
    print(f"图14生成失败: {e}")
    traceback.print_exc()

# ==================== 图15: 统计检验结果可视化 ====================
print("\n生成图15: 统计检验结果可视化")

try:
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))

    # 5a: 商品类型ANOVA结果
    ax = axes[0, 0]
    category_groups = [group['单价'].values for name, group in purchase_df.groupby('商品类型')]
    f_stat, p_val = stats.f_oneway(*category_groups)

    category_means = purchase_df.groupby('商品类型')['单价'].mean().sort_values(ascending=False)
    colors_anova = [COLORS['palette'][i % len(COLORS['palette'])] for i in range(len(category_means))]

    bars = ax.barh(range(len(category_means)), category_means.values, 
                   color=colors_anova, alpha=0.85, edgecolor='white', linewidth=1.5)
    ax.set_yticks(range(len(category_means)))
    ax.set_yticklabels(category_means.index, fontsize=10)
    ax.set_xlabel('平均客单价 (元)', fontsize=12, fontweight='bold')
    ax.grid(True, alpha=0.15, axis='x', linestyle='--')

    ax.text(0.98, 0.98, f'ANOVA检验\nF={f_stat:.2f}\np<{0.001 if p_val < 0.001 else p_val:.4f}',
            transform=ax.transAxes, fontsize=10, verticalalignment='top', horizontalalignment='right',
            bbox=dict(boxstyle='round', facecolor=COLORS['accent'], alpha=0.2, edgecolor=COLORS['accent']))

    ax.set_title('商品类型客单价差异检验', fontsize=13, fontweight='bold', pad=10)

    # 5b: 会员vs普通用户t检验
    ax = axes[0, 1]
    member_prices = purchase_df[purchase_df['权益'] == '会员']['单价']
    regular_prices = purchase_df[purchase_df['权益'] == '普通']['单价']
    t_stat, t_pval = stats.ttest_ind(member_prices, regular_prices)

    data_to_plot = [member_prices.values, regular_prices.values]
    bp = ax.boxplot(data_to_plot, labels=['会员', '普通'], patch_artist=True,
                    boxprops=dict(facecolor=COLORS['secondary'], alpha=0.7, edgecolor='white', linewidth=2),
                    medianprops=dict(color=COLORS['accent'], linewidth=2.5))

    ax.set_ylabel('客单价 (元)', fontsize=12, fontweight='bold')
    ax.grid(True, alpha=0.15, axis='y', linestyle='--')

    ax.text(0.98, 0.98, f't检验\nt={t_stat:.2f}\np<{0.001 if t_pval < 0.001 else t_pval:.4f}',
            transform=ax.transAxes, fontsize=10, verticalalignment='top', horizontalalignment='right',
            bbox=dict(boxstyle='round', facecolor=COLORS['accent'], alpha=0.2, edgecolor=COLORS['accent']))

    ax.set_title('会员vs普通用户客单价检验', fontsize=13, fontweight='bold', pad=10)

    # 5c: 年龄与购买相关性
    ax = axes[1, 0]
    user_age_purchase = purchase_df.groupby('用户ID').agg(
        年龄=('年龄', 'first'),
        购买次数=('用户ID', 'count')
    ).reset_index()

    rho, rho_pval = stats.spearmanr(user_age_purchase['年龄'], user_age_purchase['购买次数'])

    sns.regplot(x='年龄', y='购买次数', data=user_age_purchase, ax=ax,
                scatter_kws={'alpha': 0.3, 's': 30, 'color': COLORS['secondary']},
                line_kws={'color': COLORS['accent'], 'linewidth': 2.5})

    ax.set_xlabel('年龄', fontsize=12, fontweight='bold')
    ax.set_ylabel('购买次数', fontsize=12, fontweight='bold')
    ax.grid(True, alpha=0.15, linestyle='--')

    ax.text(0.02, 0.98, f'Spearman相关\nρ={rho:.3f}\np<{0.001 if rho_pval < 0.001 else rho_pval:.4f}',
            transform=ax.transAxes, fontsize=10, verticalalignment='top',
            bbox=dict(boxstyle='round', facecolor=COLORS['accent'], alpha=0.2, edgecolor=COLORS['accent']))

    ax.set_title('年龄与购买次数相关性', fontsize=13, fontweight='bold', pad=10)

    # 5d: 促销影响
    ax = axes[1, 1]
    high_discount = promo_purchase[promo_purchase['折扣量'] < 0.9].shape[0]
    low_discount = promo_purchase[promo_purchase['折扣量'] >= 0.9].shape[0]

    bars = ax.bar(['高折扣(<0.9)', '低折扣(≥0.9)'], [high_discount, low_discount],
                  color=[COLORS['success'], COLORS['warning']], alpha=0.85,
                  edgecolor='white', linewidth=2)

    for bar in bars:
        height = bar.get_height()
        ax.annotate(f'{int(height):,}',
                    xy=(bar.get_x() + bar.get_width() / 2, height),
                    xytext=(0, 8), textcoords="offset points",
                    ha='center', va='bottom', fontsize=11, fontweight='bold')

    ax.set_ylabel('购买次数', fontsize=12, fontweight='bold')
    ax.grid(True, alpha=0.15, axis='y', linestyle='--')
    ax.set_title('促销折扣影响分析', fontsize=13, fontweight='bold', pad=10)

    fig.suptitle('关键影响因素统计检验结果', fontsize=16, fontweight='bold', y=0.98)
    fig.text(0.02, 0.01, '数据来源：电商平台用户行为数据 | 显著性水平α=0.05', fontsize=9, style='italic', alpha=0.6)
    save_fig(fig, 'fig15_statistical_tests.png')
except Exception as e:
    print(f"图15生成失败: {e}")
    traceback.print_exc()

print("\n" + "="*60)
print("图14和图15生成完成!")
print("="*60)
